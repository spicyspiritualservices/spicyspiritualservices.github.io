---
title: "Edge Case: No Body Content"
excerpt: "This post has no body content and should be blank on the post's page."
categories:
  - Edge Case
tags:
  - content
  - edge case
  - layout
last_modified_at: 2017-03-09T14:23:48-05:00
---
