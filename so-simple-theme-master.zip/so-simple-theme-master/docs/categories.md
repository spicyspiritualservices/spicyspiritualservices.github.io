---
title: Category Archive
layout: categories
permalink: /categories/
show_excerpts: true
entries_layout: list
---
